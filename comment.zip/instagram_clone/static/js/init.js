(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.parallax').parallax();
	$(".dropdown-trigger").dropdown();
	$('.modal').modal();
	$('.tooltipped').tooltip();
        
  }); // end of document ready
})(jQuery); // end of jQuery name space
